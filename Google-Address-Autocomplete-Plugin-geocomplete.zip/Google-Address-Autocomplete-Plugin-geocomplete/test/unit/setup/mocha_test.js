var expect = require("chai").expect

describe("Setup - Mocha", function(){
  it("should run our tests using npm", function(){
    expect(true).to.be.ok
  })
})
